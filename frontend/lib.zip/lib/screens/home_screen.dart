import 'package:flutter/material.dart';
import 'widgets/greeting_section.dart';
import 'widgets/filter_chips.dart';
import 'widgets/hero_recommendation.dart';
import 'widgets/horizontal_section.dart';
import 'models/dummy_data.dart';

class HomeScreen extends StatelessWidget {
  const HomeScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      bottomNavigationBar: BottomNavigationBar(
        currentIndex: 0,
        items: const [
          BottomNavigationBarItem(icon: Icon(Icons.home), label: 'Home'),
          BottomNavigationBarItem(icon: Icon(Icons.search), label: 'Search'),
          BottomNavigationBarItem(icon: Icon(Icons.library_music), label: 'Library'),
          BottomNavigationBarItem(icon: Icon(Icons.person), label: 'Profile'),
        ],
      ),
      body: SafeArea(
        child: ListView(
          children: [
            GreetingSection(),
            FilterChipsWidget(),
            HeroRecommendation(),

            HorizontalSection(
              title: "Recommended for you",
              items: DummyData.recommended,
            ),

            HorizontalSection(
              title: "Popular Artists",
              items: DummyData.popular,
            ),

            HorizontalSection(
              title: "Trending Podcasts",
              items: DummyData.podcasts,
            ),
          ],
        ),
      ),
    );
  }
}
